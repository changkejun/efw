# efw
It is an ajax web framework by java for server-side javascript, and I think it may be an "Easy FrameWork".

Copyright 2015 Chang Kejun.
