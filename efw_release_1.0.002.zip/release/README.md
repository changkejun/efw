# efw -- Easy FrameWork

efw是一个Java Ajax框架.使用服务器端Javascript来开发程序.
为了制作一个面向目的的开发方式,框架里尽力减少Java Web程序开发中常发生的[数据映射]操作,
拉近Jquery和Sql,从而实现程序开发生产效率的提高.

efwは、JavaのAjax web フレームワークで、サーバーサイトのJavascriptをプログラム言語にしています。
目的向きの開発方式を目指して、Java Web プログラミングによく発生する「データのマッピング」を極力減らし、
クライアントのJqueryとサーバーのSqlを近くさせて、生産性がアップを実現します。

Efw is an Ajax web framework by Java for server-side Javascript language.
Aiming to develop a method of purpose oriented, it reduces "Data Mapping" which is well occured in Java Web programming,
to close the distance of Jquery and Sql, in order to impove the programming productivity.

Copyright 2015 Chang Kejun.
